import './bootstrap';
import 'flowbite';
import 'flowbite/dist/flowbite.min.js';
import $ from 'jquery';
import DataTable from 'datatables.net-dt';
import 'datatables.net-dt/css/jquery.dataTables.css';
import './theme-toggle';
import './sidebar';

window.$ = $;
window.jQuery = $;
DataTable(window, $);

$(document).ready(function () {
    const tableElement = $('#eventosTable');
    if (!tableElement.length) {
        return;
    }

    const table = tableElement.DataTable({
        processing: true,
        serverSide: true,
        ajax: tableElement.data('url') || '/eventos/data',
        dom:
            "<'flex flex-col sm:flex-row justify-between items-center mb-4'<'flex items-center space-x-4'l><'relative w-full sm:w-auto mt-2 sm:mt-0'f>>" +
            "<'overflow-x-auto'tr>" +
            "<'flex flex-col sm:flex-row justify-between items-center mt-4'p>",
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/es-ES.json',
        },
        columns: [
            { data: 'nombreEvento', name: 'nombreEvento' },
            { data: 'fecha', name: 'fecha' },
            { data: 'hora', name: 'hora' },
            { data: 'ubicacion', name: 'ubicacion' },
            { data: 'registrados', name: 'registrados', className: 'text-center' },
            {
                data: 'estado',
                render: (data) => {
                    const color =
                        data === 'Activo'
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
                    return `<span class='px-3 py-1 text-xs font-semibold rounded-full ${color}'>${data}</span>`;
                },
            },
            {
                data: 'acciones',
                orderable: false,
                searchable: false,
                className: 'text-center',
            },
        ],
    });

    $('#searchInput').on('keyup', function () {
        table.search(this.value).draw();
    });
});
