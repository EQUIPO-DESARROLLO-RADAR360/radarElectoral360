@extends('layouts.app')

@section('title', 'Eventos - Radar Electoral 360')
@section('page_title', 'Eventos')
@section('page_subtitle', 'Gestiona la agenda, asistentes y comunicación de cada encuentro en tiempo real')

@section('content')
<div class="space-y-6">
    <section class="rounded-3xl border border-slate-800/60 bg-slate-900/80 text-slate-100 shadow-2xl shadow-slate-950/45 transition-colors duration-300">
        <div class="px-6 py-6 sm:px-8 sm:py-7 lg:px-10 lg:py-8 space-y-6">
            <div class="relative overflow-hidden shadow-md sm:rounded-lg">
                <div class="flex flex-col items-center justify-between gap-3 p-4 bg-white dark:bg-gray-900 sm:flex-row">
                    <button type="button" data-modal-target="nuevoEventoModal" data-modal-toggle="nuevoEventoModal" class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-800">
                        Nuevo evento
                    </button>
                    <div class="relative mt-3 w-full sm:mt-0 sm:w-auto">
                        <div class="pointer-events-none absolute inset-y-0 left-3 flex items-center">
                            <span class="ph ph-magnifying-glass text-gray-400 dark:text-gray-500"></span>
                        </div>
                        <input id="searchInput" type="text" placeholder="Buscar..." class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2 pl-10 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400">
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table id="eventosTable" data-url="{{ route('eventos.data') }}" class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">Nombre</th>
                                <th scope="col" class="px-6 py-3">Fecha</th>
                                <th scope="col" class="px-6 py-3">Hora</th>
                                <th scope="col" class="px-6 py-3">Ubicación</th>
                                <th scope="col" class="px-6 py-3 text-center">Registrados</th>
                                <th scope="col" class="px-6 py-3 text-center">Estado</th>
                                <th scope="col" class="px-6 py-3 text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    @include('eventos.partials.modal-create')
</div>
@endsection
