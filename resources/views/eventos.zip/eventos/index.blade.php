@extends('layouts.app')

@section('title', 'Eventos - Radar Electoral 360')
@section('page_title', 'Eventos')
@section('page_subtitle', 'Gestiona la agenda, asistentes y comunicación de cada encuentro en tiempo real')

@section('content')
    <div class="space-y-6">
        <section
            class="rounded-3xl border border-slate-800/60 bg-slate-900/80 text-slate-100 shadow-2xl shadow-slate-950/45 transition-colors duration-300">
            <div class="px-6 py-6 sm:px-8 sm:py-7 lg:px-10 lg:py-8 space-y-6">
                <div id="app">
                    <eventos-index url="{{ route('eventos.data') }}"></eventos-index>
                </div>
            </div>
        </section>

        @include('eventos.partials.modal-create')
    </div>
@endsection