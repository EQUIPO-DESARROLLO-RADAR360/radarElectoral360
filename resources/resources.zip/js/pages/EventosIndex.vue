<template>
    <div class="space-y-6">
        <!-- Quick Filters -->
        <div class="flex flex-wrap gap-2">
            <button @click="filter = 'all'"
                :class="['px-4 py-2 text-sm font-medium rounded-full transition-colors', filter === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700']">
                Todos
            </button>
            <button @click="filter = 'upcoming'"
                :class="['px-4 py-2 text-sm font-medium rounded-full transition-colors', filter === 'upcoming' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700']">
                Próximos
            </button>
            <button @click="filter = 'active'"
                :class="['px-4 py-2 text-sm font-medium rounded-full transition-colors', filter === 'active' ? 'bg-green-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700']">
                Activos
            </button>
            <button @click="filter = 'finished'"
                :class="['px-4 py-2 text-sm font-medium rounded-full transition-colors', filter === 'finished' ? 'bg-gray-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700']">
                Finalizados
            </button>
        </div>

        <ServerSideTable :url="url" :columns="columns" :additionalParams="{ scope: filter }">
            
            <!-- Custom Slot for 'registrados' -->
            <template #registrados="{ value }">
                 <div class="text-center">
                    <span class="inline-flex items-center justify-center px-2 py-1 mr-2 text-xs font-bold leading-none text-blue-100 bg-blue-600 rounded-full">
                        {{ value }}
                    </span>
                 </div>
            </template>

            <!-- Custom Slot for 'estado' -->
            <template #estado="{ value }">
                <span class="px-3 py-1 text-xs font-semibold rounded-full"
                    :class="{
                        'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300': value === 'Activo',
                        'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300': value === 'Finalizado',
                        'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300': value === 'Cancelado',
                        'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300': value === 'Programado' // Adding default fallback just in case
                    }">
                    {{ value }}
                </span>
            </template>

            <!-- Custom Slot for 'acciones' -->
            <template #acciones="{ item }">
                <div class="flex items-center justify-center space-x-2">
                    <a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline" title="Ver">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                    </a>
                    <a href="#" class="font-medium text-yellow-600 dark:text-yellow-500 hover:underline" title="Editar">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                    </a>
                    <button class="font-medium text-red-600 dark:text-red-500 hover:underline" title="Eliminar">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                </div>
            </template>

            <!-- Mobile Card Layout -->
            <template #mobile-card="{ item }">
                <div class="flex flex-col space-y-3">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="font-bold text-gray-900 dark:text-white text-lg">{{ item.nombreEvento }}</h3>
                            <p class="text-sm text-gray-500 dark:text-gray-400">{{ item.fecha }} | {{ item.hora }}</p>
                        </div>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full"
                            :class="{
                                'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300': item.estado === 'Activo',
                                'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300': item.estado === 'Finalizado',
                                'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300': item.estado === 'Cancelado'
                            }">
                            {{ item.estado }}
                        </span>
                    </div>
                    
                    <div class="text-sm text-gray-700 dark:text-gray-300">
                        <div class="flex items-center gap-2">
                             <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                             {{ item.ubicacion }}
                        </div>
                    </div>

                    <div class="flex justify-between items-center pt-2 border-t border-gray-100 dark:border-gray-700">
                        <div class="text-xs text-gray-500">
                            Registrados: <span class="font-bold text-gray-900 dark:text-white">{{ item.registrados }}</span>
                        </div>
                        <div class="flex gap-3">
                             <a href="#" class="text-blue-600 dark:text-blue-400"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg></a>
                             <a href="#" class="text-yellow-600 dark:text-yellow-400"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg></a>
                        </div>
                    </div>
                </div>
            </template>
        </ServerSideTable>
    </div>
</template>

<script setup>
import { ref } from 'vue';
import ServerSideTable from '../components/ServerSideTable.vue';

const props = defineProps({
    url: {
        type: String,
        required: true
    }
});

const filter = ref('all');

const columns = [
    { label: 'Nombre del Evento', key: 'nombreEvento' },
    { label: 'Fecha', key: 'fecha' },
    { label: 'Hora', key: 'hora' },
    { label: 'Ubicación', key: 'ubicacion' },
    { label: 'Registrados', key: 'registrados' },
    { label: 'Estado', key: 'estado' },
    { label: 'Acciones', key: 'acciones' }
];
</script>
