<template>
    <div class="space-y-4">
        <!-- Controls -->
        <div class="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
            <div class="flex items-center space-x-2">
                <label class="text-sm text-gray-600 dark:text-gray-400">Mostrar</label>
                <select v-model="length" @change="resetAndFetch"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option :value="10">10</option>
                    <option :value="25">25</option>
                    <option :value="50">50</option>
                    <option :value="100">100</option>
                </select>
            </div>
            <div class="relative w-full sm:w-64">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                    </svg>
                </div>
                <input type="text" v-model="search" @input="debouncedFetch"
                    class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Buscar...">
            </div>
        </div>

        <!-- Desktop View: Table -->
        <div class="hidden md:block relative overflow-x-auto shadow-md sm:rounded-lg">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th v-for="(col, index) in columns" :key="index" scope="col" class="px-6 py-3 cursor-pointer"
                            @click="sortBy(index)">
                            <div class="flex items-center">
                                {{ col.label }}
                                <span v-if="orderColumn === index" class="ml-1">
                                    <svg v-if="orderDirection === 'asc'" class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19V5m0 14-4-4m4 4 4-4"/></svg>
                                    <svg v-else class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v14m0-14 4 4m-4-4-4 4"/></svg>
                                </span>
                            </div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-if="loading">
                        <td :colspan="columns.length" class="px-6 py-4 text-center">
                            Cargando...
                        </td>
                    </tr>
                    <tr v-else-if="data.length === 0">
                        <td :colspan="columns.length" class="px-6 py-4 text-center">
                            No se encontraron registros
                        </td>
                    </tr>
                    <tr v-else v-for="(item, index) in data" :key="index"
                        class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <td v-for="(col, colIndex) in columns" :key="colIndex" class="px-6 py-4">
                            <slot :name="col.key" :item="item" :value="item[col.key]">
                                <span v-html="renderCell(item, col)"></span>
                            </slot>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Mobile View: Cards -->
        <div class="md:hidden space-y-4">
            <div v-if="loading" class="text-center py-4">Cargando...</div>
            <div v-else-if="data.length === 0" class="text-center py-4">No se encontraron registros</div>
            <div v-else v-for="(item, index) in data" :key="index"
                class="bg-white dark:bg-gray-800 text-gray-900 dark:text-white p-4 rounded-lg shadow border border-gray-200 dark:border-gray-700">
                <slot name="mobile-card" :item="item">
                    <!-- Default Mobile Card -->
                    <div class="flex flex-col space-y-2">
                        <div v-for="(col, colIndex) in columns" :key="colIndex" class="flex justify-between">
                            <span class="font-bold text-sm text-gray-500 dark:text-gray-400">{{ col.label }}</span>
                            <span class="text-sm" v-html="renderCell(item, col)"></span>
                        </div>
                    </div>
                </slot>
            </div>
        </div>

        <!-- Pagination -->
        <div class="flex flex-col items-center">
            <span class="text-sm text-gray-700 dark:text-gray-400 mb-2">
                Mostrando <span class="font-semibold text-gray-900 dark:text-white">{{ from }}</span> a <span
                    class="font-semibold text-gray-900 dark:text-white">{{ to }}</span> de <span
                    class="font-semibold text-gray-900 dark:text-white">{{ total }}</span> entradas
            </span>
            <div class="inline-flex mt-2 xs:mt-0">
                <button @click="prevPage" :disabled="page === 1"
                    class="flex items-center justify-center px-3 h-8 text-sm font-medium text-white bg-gray-800 rounded-s hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white disabled:opacity-50">
                    Anterior
                </button>
                <button @click="nextPage" :disabled="to >= total"
                    class="flex items-center justify-center px-3 h-8 text-sm font-medium text-white bg-gray-800 border-0 border-s border-gray-700 rounded-e hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white disabled:opacity-50">
                    Siguiente
                </button>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import axios from 'axios';
import { debounce } from 'lodash';

const props = defineProps({
    url: {
        type: String,
        required: true
    },
    columns: {
        type: Array,
        required: true
    },
    additionalParams: {
        type: Object,
        default: () => ({})
    }
});

const data = ref([]);
const loading = ref(false);
const total = ref(0);
const length = ref(10);
const start = ref(0);
const search = ref('');
const orderColumn = ref(0);
const orderDirection = ref('asc');

const page = ref(1);

const from = ref(0);
const to = ref(0);

const fetchData = async () => {
    loading.value = true;
    try {
        const response = await axios.get(props.url, {
            params: {
                draw: Date.now(),
                start: start.value,
                length: length.value,
                search: { value: search.value, regex: false },
                order: [{ column: orderColumn.value, dir: orderDirection.value }],
                columns: props.columns.map(col => ({ data: col.key, name: col.key, searchable: true, orderable: true })),
                ...props.additionalParams
            }
        });

        const json = response.data;
        data.value = json.data;
        total.value = json.recordsTotal; // Or recordsFiltered depending on backend impl, but DataTables usually uses recordsTotal for total vs filtered
        
        // Update range indicators
        from.value = total.value === 0 ? 0 : start.value + 1;
        to.value = Math.min(start.value + length.value, total.value);

    } catch (error) {
        console.error("Error fetching data:", error);
    } finally {
        loading.value = false;
    }
};

const debouncedFetch = debounce(() => {
    start.value = 0;
    page.value = 1;
    fetchData();
}, 300);

const resetAndFetch = () => {
    start.value = 0;
    page.value = 1;
    fetchData();
};

const nextPage = () => {
    if (to.value < total.value) {
        page.value++;
        start.value += length.value;
        fetchData();
    }
};

const prevPage = () => {
    if (page.value > 1) {
        page.value--;
        start.value -= length.value;
        fetchData();
    }
};

const sortBy = (index) => {
    if (orderColumn.value === index) {
        orderDirection.value = orderDirection.value === 'asc' ? 'desc' : 'asc';
    } else {
        orderColumn.value = index;
        orderDirection.value = 'asc';
    }
    fetchData();
};

const renderCell = (item, col) => {
    // If column has specific rendering logic that isn't a slot, handle it here if needed.
    // However, it's better to use slots or just return the value.
    // Since we receive JSON data, we can just return item[col.key].
    // If the backend sends HTML (like DataTables sometimes does), v-html handles it.
    return item[col.key];
};

watch(() => props.additionalParams, () => {
    resetAndFetch();
}, { deep: true });

onMounted(() => {
    fetchData();
});
</script>
