@extends('layouts.app')

@section('title', 'Eventos - Radar Electoral 360')

@section('content')
<div class="row mb-4">
    <div class="col-12">
        <h1 class="h3 mb-0">Eventos</h1>
        <p class="text-muted">Gestión de eventos y registros</p>
    </div>
</div>

<!-- Actions -->
<div class="row mb-4">
    <div class="col-12">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#nuevoEventoModal">
            <span class="material-icons-outlined me-1" style="font-size: 18px; vertical-align: middle;">add</span>
            Nuevo Evento
        </button>
        <button class="btn btn-outline-secondary" id="refreshTable">
            <span class="material-icons-outlined me-1" style="font-size: 18px; vertical-align: middle;">refresh</span>
            Actualizar
        </button>
    </div>
</div>

<!-- DataTable -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white border-0 py-3">
        <h5 class="mb-0">Lista de Eventos Registrados</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="eventosTable" class="table table-striped table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre del Evento</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Ubicación</th>
                        <th>Registrados</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables will populate this via server-side processing -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Nuevo Evento -->
<div class="modal fade" id="nuevoEventoModal" tabindex="-1" aria-labelledby="nuevoEventoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="nuevoEventoModalLabel">Nuevo Evento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="nuevoEventoForm">
                    <div class="mb-3">
                        <label for="nombreEvento" class="form-label">Nombre del Evento</label>
                        <input type="text" class="form-control" id="nombreEvento" required>
                    </div>
                    <div class="mb-3">
                        <label for="fechaEvento" class="form-label">Fecha</label>
                        <input type="date" class="form-control" id="fechaEvento" required>
                    </div>
                    <div class="mb-3">
                        <label for="horaEvento" class="form-label">Hora</label>
                        <input type="time" class="form-control" id="horaEvento" required>
                    </div>
                    <div class="mb-3">
                        <label for="ubicacionEvento" class="form-label">Ubicación</label>
                        <input type="text" class="form-control" id="ubicacionEvento" required>
                    </div>
                    <div class="mb-3">
                        <label for="descripcionEvento" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcionEvento" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarEvento">Guardar</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    #eventosTable_wrapper .dataTables_filter {
        margin-bottom: 1rem;
    }
    #eventosTable_wrapper .dataTables_length {
        margin-bottom: 1rem;
    }
</style>
@endpush

@push('scripts')
<script>
    $(document).ready(function() {
        var table = $('#eventosTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('eventos.data') }}",
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            },
            columns: [
                { data: 'id', name: 'id' },
                { data: 'nombre', name: 'nombre' },
                { data: 'fecha', name: 'fecha' },
                { data: 'hora', name: 'hora' },
                { data: 'ubicacion', name: 'ubicacion' },
                { data: 'registrados', name: 'registrados' },
                { 
                    data: 'estado', 
                    name: 'estado',
                    render: function(data, type, row) {
                        var badgeClass = data === 'Activo' ? 'bg-success' : 
                                        data === 'Finalizado' ? 'bg-secondary' : 'bg-warning';
                        return '<span class="badge ' + badgeClass + '">' + data + '</span>';
                    }
                },
                { 
                    data: 'acciones', 
                    name: 'acciones',
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row) {
                        return '<button class="btn btn-sm btn-outline-primary me-1" title="Editar" onclick="editarEvento(' + row.id + ')">' +
                               '<span class="material-icons-outlined" style="font-size: 18px;">edit</span>' +
                               '</button>' +
                               '<button class="btn btn-sm btn-outline-danger" title="Eliminar" onclick="eliminarEvento(' + row.id + ')">' +
                               '<span class="material-icons-outlined" style="font-size: 18px;">delete</span>' +
                               '</button>';
                    }
                }
            ],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
            },
            order: [[0, 'desc']],
            pageLength: 10,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]]
        });

        // Refresh table button
        $('#refreshTable').on('click', function() {
            table.ajax.reload();
        });

        // Guardar nuevo evento
        $('#guardarEvento').on('click', function() {
            var formData = {
                nombre: $('#nombreEvento').val(),
                fecha: $('#fechaEvento').val(),
                hora: $('#horaEvento').val(),
                ubicacion: $('#ubicacionEvento').val(),
                descripcion: $('#descripcionEvento').val()
            };

            $.ajax({
                url: "{{ route('eventos.store') }}",
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: formData,
                success: function(response) {
                    $('#nuevoEventoModal').modal('hide');
                    $('#nuevoEventoForm')[0].reset();
                    table.ajax.reload();
                    alert('Evento creado exitosamente');
                },
                error: function(xhr) {
                    alert('Error al crear el evento');
                }
            });
        });
    });

    function editarEvento(id) {
        // Implementar lógica de edición
        alert('Editar evento ID: ' + id);
    }

    function eliminarEvento(id) {
        if (confirm('¿Está seguro de eliminar este evento?')) {
            $.ajax({
                url: "{{ route('eventos.destroy', ':id') }}".replace(':id', id),
                type: "DELETE",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#eventosTable').DataTable().ajax.reload();
                    alert('Evento eliminado exitosamente');
                },
                error: function(xhr) {
                    alert('Error al eliminar el evento');
                }
            });
        }
    }
</script>
@endpush

