@extends('layouts.app')

@section('title', 'Dashboard - Radar Electoral 360')

@section('content')
<div class="row mb-4">
    <div class="col-12">
        <h1 class="h3 mb-0">Dashboard</h1>
        <p class="text-muted">Vista general del sistema</p>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Total Electores</h6>
                        <h2 class="mb-0 text-primary">12,345</h2>
                        <small class="text-success">
                            <span class="material-icons-outlined" style="font-size: 14px; vertical-align: middle;">trending_up</span>
                            +12.5%
                        </small>
                    </div>
                    <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                        <span class="material-icons text-primary" style="font-size: 32px;">people</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Ciudadanos</h6>
                        <h2 class="mb-0 text-success">8,234</h2>
                        <small class="text-success">
                            <span class="material-icons-outlined" style="font-size: 14px; vertical-align: middle;">trending_up</span>
                            +8.2%
                        </small>
                    </div>
                    <div class="bg-success bg-opacity-10 rounded-circle p-3">
                        <span class="material-icons text-success" style="font-size: 32px;">person</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Afiliados</h6>
                        <h2 class="mb-0 text-info">5,678</h2>
                        <small class="text-success">
                            <span class="material-icons-outlined" style="font-size: 14px; vertical-align: middle;">trending_up</span>
                            +5.1%
                        </small>
                    </div>
                    <div class="bg-info bg-opacity-10 rounded-circle p-3">
                        <span class="material-icons text-info" style="font-size: 32px;">groups</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-2">Eventos</h6>
                        <h2 class="mb-0 text-warning">234</h2>
                        <small class="text-success">
                            <span class="material-icons-outlined" style="font-size: 14px; vertical-align: middle;">trending_up</span>
                            +3.4%
                        </small>
                    </div>
                    <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                        <span class="material-icons text-warning" style="font-size: 32px;">event</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts and Tables -->
<div class="row g-4">
    <div class="col-lg-8">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-0">Actividad Reciente</h5>
            </div>
            <div class="card-body">
                <canvas id="activityChart" height="300"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="mb-0">Distribución por Región</h5>
            </div>
            <div class="card-body">
                <canvas id="regionChart" height="300"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mt-2">
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Registros Recientes</h5>
                <a href="{{ route('gestion.index') }}" class="btn btn-sm btn-primary">
                    Ver todos
                    <span class="material-icons-outlined" style="font-size: 18px; vertical-align: middle;">arrow_forward</span>
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>DNI</th>
                                <th>Tipo</th>
                                <th>Fecha</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#001</td>
                                <td>Juan Pérez</td>
                                <td>12345678</td>
                                <td><span class="badge bg-primary">Elector</span></td>
                                <td>2024-01-15</td>
                                <td><span class="badge bg-success">Activo</span></td>
                            </tr>
                            <tr>
                                <td>#002</td>
                                <td>María García</td>
                                <td>87654321</td>
                                <td><span class="badge bg-success">Ciudadano</span></td>
                                <td>2024-01-14</td>
                                <td><span class="badge bg-success">Activo</span></td>
                            </tr>
                            <tr>
                                <td>#003</td>
                                <td>Carlos López</td>
                                <td>11223344</td>
                                <td><span class="badge bg-info">Afiliado</span></td>
                                <td>2024-01-13</td>
                                <td><span class="badge bg-success">Activo</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
    // Activity Chart
    const ctx1 = document.getElementById('activityChart');
    if (ctx1) {
        new Chart(ctx1, {
            type: 'line',
            data: {
                labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
                datasets: [{
                    label: 'Registros',
                    data: [12, 19, 15, 25, 22, 30],
                    borderColor: 'rgb(13, 110, 253)',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    // Region Chart
    const ctx2 = document.getElementById('regionChart');
    if (ctx2) {
        new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: ['Norte', 'Sur', 'Este', 'Oeste', 'Centro'],
                datasets: [{
                    data: [30, 25, 20, 15, 10],
                    backgroundColor: [
                        'rgb(13, 110, 253)',
                        'rgb(25, 135, 84)',
                        'rgb(13, 202, 240)',
                        'rgb(255, 193, 7)',
                        'rgb(220, 53, 69)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
</script>
@endpush

