<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class EventosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('eventos.index');
    }

    /**
     * Get data for DataTables (Server-side processing)
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function data(Request $request)
    {
        // This is a sample implementation. In a real application, you would query your database
        // For now, we'll return sample data
        
        $draw = $request->get('draw');
        $start = $request->get('start');
        $length = $request->get('length');
        $search = $request->get('search')['value'] ?? '';
        $orderColumn = $request->get('order')[0]['column'] ?? 0;
        $orderDir = $request->get('order')[0]['dir'] ?? 'asc';
        
        // Sample data - Replace with actual database query
        $eventos = [
            [
                'id' => 1,
                'nombre' => 'Asamblea General',
                'fecha' => '2024-01-20',
                'hora' => '10:00',
                'ubicacion' => 'Centro de Convenciones',
                'registrados' => 150,
                'estado' => 'Activo'
            ],
            [
                'id' => 2,
                'nombre' => 'Reunión de Coordinación',
                'fecha' => '2024-01-18',
                'hora' => '14:00',
                'ubicacion' => 'Oficina Central',
                'registrados' => 45,
                'estado' => 'Activo'
            ],
            [
                'id' => 3,
                'nombre' => 'Evento de Campaña',
                'fecha' => '2024-01-15',
                'hora' => '18:00',
                'ubicacion' => 'Plaza Principal',
                'registrados' => 320,
                'estado' => 'Finalizado'
            ],
            [
                'id' => 4,
                'nombre' => 'Taller de Capacitación',
                'fecha' => '2024-01-22',
                'hora' => '09:00',
                'ubicacion' => 'Sala de Conferencias',
                'registrados' => 80,
                'estado' => 'Programado'
            ],
            [
                'id' => 5,
                'nombre' => 'Foro Electoral',
                'fecha' => '2024-01-25',
                'hora' => '16:00',
                'ubicacion' => 'Auditorio Municipal',
                'registrados' => 200,
                'estado' => 'Programado'
            ],
        ];

        // Apply search filter
        if (!empty($search)) {
            $eventos = array_filter($eventos, function($evento) use ($search) {
                return stripos($evento['nombre'], $search) !== false ||
                       stripos($evento['ubicacion'], $search) !== false ||
                       stripos($evento['estado'], $search) !== false;
            });
        }

        // Apply sorting
        $columns = ['id', 'nombre', 'fecha', 'hora', 'ubicacion', 'registrados', 'estado'];
        if (isset($columns[$orderColumn])) {
            usort($eventos, function($a, $b) use ($orderColumn, $orderDir, $columns) {
                $col = $columns[$orderColumn];
                $cmp = $a[$col] <=> $b[$col];
                return $orderDir === 'asc' ? $cmp : -$cmp;
            });
        }

        // Paginate
        $total = count($eventos);
        $eventos = array_slice($eventos, $start, $length);

        // Format data for DataTables
        $data = [];
        foreach ($eventos as $evento) {
            $data[] = [
                'id' => $evento['id'],
                'nombre' => $evento['nombre'],
                'fecha' => $evento['fecha'],
                'hora' => $evento['hora'],
                'ubicacion' => $evento['ubicacion'],
                'registrados' => $evento['registrados'],
                'estado' => $evento['estado'],
                'acciones' => ''
            ];
        }

        return response()->json([
            'draw' => intval($draw),
            'recordsTotal' => $total,
            'recordsFiltered' => $total,
            'data' => $data
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha' => 'required|date',
            'hora' => 'required',
            'ubicacion' => 'required|string|max:255',
            'descripcion' => 'nullable|string'
        ]);

        // In a real application, you would save to database here
        // Evento::create($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Evento creado exitosamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // In a real application, you would delete from database here
        // Evento::findOrFail($id)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Evento eliminado exitosamente'
        ]);
    }
}

